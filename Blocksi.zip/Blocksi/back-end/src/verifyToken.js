import jwt from "jsonwebtoken"

const JWT_SECRET = "jodjqopj_yéFSOJ#[#{QFNQKFENE38~@@2YAEavbnzsdLDZ3"

function auth (req, res, next){
    const token= req.header('auth-token');
    if (!token){
        return res.json({status:"error", error:"Access Denied"});
    }
    try{
        const verified = jwt.verify(token, JWT_SECRET);
        req.user = verified;
    }catch(error){
        return res.json({status:"error", error:"Invalid Token"});
    }
}

export default auth;