import express from 'express';
import bodyParser from 'body-parser';
import mongoose from "mongoose"
import User from "./user"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import Contacts from "./contactList"


// *** Clé secrete pour le token ****
const JWT_SECRET = "jodjqopj_yéFSOJ#[#{QFNQKFENE38~@@2YAEavbnzsdLDZ3"

//*** Connexion à la base de donnée databaseBlocksi (collection : user, contacts)***/
mongoose.connect('mongodb://localhost:27017/databaseBlocksi',  {
    useNewUrlParser: true,
    useUnifiedTopology : true,
    useCreateIndex : true
})


const app = express();
app.use(bodyParser.json());

// ********Vérification de l'authenticité de l'utilisateur *******
const verify = (token) => {
    try{
        const verified = jwt.verify(token, JWT_SECRET);
        return true;
    }catch(error){
        return false;
    }
}


// ************ Inscription d'un nouvel utilisateur *******************

app.post('/api/register', async (req, res) => { 
    const {username, password : plainTextPassword} = req.body;
    if (!username && !plainTextPassword){
        return res.json({status:'error', error: 'No username or password entered'})
    }
    if (!username || typeof username !=='string'){
        return res.json({status:'error', error: 'Invalid username'})
    }
    if (!plainTextPassword || typeof plainTextPassword !=='string'){
        return res.json({status:'error', error: 'Invalid password'})
    }

    if (plainTextPassword.length<5){
        return res.json({status:'error', error: 'Password too small. Should be at least 6 characters.'})
    }
    
    // We need to hash the password for security : (bcryptjs)
    const password = await bcrypt.hash(plainTextPassword, 10)
    //Adding in the database
    try {
        const response = await User.create({
            username, 
            password
        });
        res.json({status:"ok"})
    } catch(error) {
        if (error.code === 11000){
            return res.json({status:"error", error:"Username already in use"})
        }
        console.log(JSON.stringify(error))
        res.json({status:"error", error:"Error with the connexion to the database"})
    }
})

// ************ Connexion au site  *******************
app.post('/api/login', async (req, res) => { 
    const {username, password: plainTextPassword} = req.body;
    if (!username && !plainTextPassword){
        return res.json({status:'error', error: 'No username or password entered'})
    }
    if(!username || typeof username !=='string'){
        return res.json({status:'error', error: 'Invalid username'})
    }
    if (!plainTextPassword || typeof plainTextPassword !=='string'){
        return res.json({status:'error', error: 'Invalid password'})
    }
    //Searching in the database for this user 
    try {
        const user = await User.findOne({username}).lean();
        if (!user) {
            return res.json({status:"error", error:"Wrong username or password."})
        }
        if (await bcrypt.compare(plainTextPassword, user.password)) {
            // the (username, password) combination is successful

            //création du jeton client-serveur sous forme de jwt (header, payload, signature)
            const token = jwt.sign(
                {
                id: user._id,
                username : user.username
            }, 
                JWT_SECRET
            )
            return res.json({token: token})
        }
        else{
            return res.json({status:"error", error:"Wrong password"});
        }
    } catch(error) {
        res.json({status:"error", error:"Error with the connexion to the database"})
    }
})


// *********** Affichage de la liste de contacts **************// 
app.get('/api/ContactList',  async (req, res) => {
    
    // Vérfication de l'authenticité de l'utilisateur 
    const token= req.header('auth-token');
    if (!token){
        return res.json({status:"error", error:"Access Denied"});
    }
    const isAuthentic = verify(token);
    if (!isAuthentic){
        res.json({status:"error", error : "Invalid Token"})
    }

    // Récupération des contacts
    const contacts = await Contacts.find().lean();
    if (!contacts) {
        return res.json({status:"error", error:"No contact"})
    }
    res.json({status:"ok", data:contacts});
})

// *********** Display a specific contact **************// 
app.get('/api/:filter', async (req, res) => {

        // Vérfication de l'authenticité de l'utilisateur 
    const token= req.header('auth-token');
    if (!token){
        return res.json({status:"error", error:"Access Denied"});
    }
    const isAuthentic = verify(token);
    if (!isAuthentic){
        res.json({status:"error", error : "Invalid Token"})
    }

    // Récupération de l'utilisateur recherché 
    try{
        const filter= req.params.filter;
        const filterFirstLetterUpperCase = filter.charAt(0).toUpperCase() + filter.slice(1);
        const firstName = await Contacts.find({firstName: filterFirstLetterUpperCase}).lean();
        const lastName = await Contacts.find({lastName: filterFirstLetterUpperCase}).lean();

        Array.prototype.push.apply(firstName,lastName);
        if (firstName == [] && lastName == []){
            return res.json({status:"error", error:"This contact doesn't exist"})
        }
        else {
            return res.json({status:"ok", data:firstName})
        }
    } catch (error){
        res.json({status:"error", error:"Error with the connexion to the database"})
    }
})


// *********** Modification d'un contact **************// 

app.put('/api/:firstAndLastName', async (req, res) => {
    // Vérfication de l'authenticité de l'utilisateur 
    const token= req.header('auth-token');
    if (!token){
        return res.json({status:"error", error:"Access Denied"});
    }
    const isAuthentic = verify(token);
    if (!isAuthentic){
        res.json({status:"error", error : "Invalid Token"})
    }
    //Modification du numéro de téléphone de la personne recherchée 
    try{
        const firstAndLastName= req.params.firstAndLastName;
        const contactInfo = firstAndLastName.split(",");
        const firstName = contactInfo[0];
        const lastName = contactInfo[1];
        const {phoneNumber, token} = req.body;
        const contact = await Contacts.findOneAndUpdate({firstName: firstName, lastName: lastName}, {phoneNumber : phoneNumber}, {new:true}, (error, data) => {
            if (error){
                console.log(error)
            }else{
                console.log(data)
            }
        })
        if (!contact) {
            return res.json({status:"error", error:"This contact doesn't exist"})
        }
        res.json({status:"ok", data:contact});

    } catch (error){
        res.json({status:"error", error:"Error with the connexion to the database"})
    }
})

// *********** Suppression d'un contact **************// 

app.delete('/api/:firstAndLastName',  async (req, res) => {
    // Vérfication de l'authenticité de l'utilisateur 
    const token= req.header('auth-token');
    if (!token){
        return res.json({status:"error", error:"Access Denied"});
    }
    const isAuthentic = verify(token);
    if (!isAuthentic){
        res.json({status:"error", error : "Invalid Token"})
            }

    //Suppression du contact recherché 
    try{
        const firstAndLastName= req.params.firstAndLastName;
        const contactInfo = firstAndLastName.split(",");
        const firstName = contactInfo[0];
        const lastName = contactInfo[1];
        const contact = await Contacts.findOneAndRemove({firstName: firstName, lastName: lastName}, (error, data) => {
            if (error){
                console.log(error)
            }else{
                console.log(data)
            }
        })
        const newContactList = await Contacts.find();
        res.json({status:"ok", data:newContactList});

    } catch (error){
        res.json({status:"error", error:"Error with the connexion to the database"})
    }
})




app.listen(8000, () => console.log('Listening on port 8000'));
