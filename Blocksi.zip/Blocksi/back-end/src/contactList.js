const mongoose = require ('mongoose')

const ContactSchema = new mongoose.Schema(
    {
    firstName : {type : String, required: true},
    lastName : {type : String, required: true},
    phoneNumber : {type : String, required: true}, //(à changer pour numéro à 10 chiffres)


    },
    {collection : 'contacts'}
)

const model = mongoose.model('ContactSchema', ContactSchema)

module.exports = model
