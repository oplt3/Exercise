import React, {useState} from 'react';
import {useHistory} from "react-router-dom"

//***** Connexion au site ********

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const history = useHistory();

    const IntentLogin = async () => {
        const result = await fetch(`/api/login`, {
            method: 'post',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({username: username, password: password}),
        });
        const body = await result.json();
        if (body.status === "error")
        {   
            alert(body.error)
        }
        else{
            alert('Successful login');
            localStorage.setItem('token', body.token);
             //Redirect to ContactList : 
            history.push("/login");
        }

        setUsername('');
        setPassword('');
    }

    return(
        <div className="entry">
        <h3>Login</h3>
        <label>
            <input type="text" placeholder="Username" value={username} onChange={(event) => setUsername(event.target.value)} />
        </label>
        <label>
            <input type="password" placeholder="Password" value={password} onChange={(event) => setPassword(event.target.value)} />
        </label>
        <button onClick={() => IntentLogin()}>Login</button>
        
    </div>
    )
}


export default Login;