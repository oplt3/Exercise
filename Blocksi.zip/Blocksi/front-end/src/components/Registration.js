import React, { useState } from 'react';


// *** Inscription sur le site ****

const Registration = () => {
    
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const addUser = async () => {
        const result = await fetch(`/api/register`, {
            method: 'post',
            crossDomain:true,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
              },
            body: JSON.stringify({ username: username, password: password}),
        });
        const body = await result.json();
        console.log(body)
        if (body.status === "error"){
            alert(body.error);
        }
        else{
            alert("Successful registration");
        }
        setUsername('');
        setPassword('');
    }
    return(
        <div className="entry">
        <h3>Register</h3>
        <label>
            <input type="text" placeholder="Username" value={username} onChange={(event) => setUsername(event.target.value)} />
        </label>
        <label>
            <input type="password" placeholder="Password" value={password} onChange={(event) => setPassword(event.target.value)} />
        </label>
        <button onClick={() => addUser()}>Register</button>
        
    </div>
    )
}


export default Registration;