import React, {useEffect, useState} from "react";
import {IoIosTrash} from "react-icons/io"
import {FaUserEdit} from "react-icons/fa"
// **** Affichage de la liste de contacts ********

const DisplayContactList = () => {

    const [contactInfo, setContactInfo] = useState([])
    const [contactInfoFiltered, setContactInfoFiltered] = useState([])
    const [isSearch, setIsSearch] = useState(false)
    const [filter, setFilter] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const [isEditing, setIsEditing] = useState(false);
    const [firstAndLastName, setfirstAndLastName] = useState();

    //function to display contact list
    const displayList = (contactsInfo) => {
        return (
        contactsInfo.map((info,key) => (
        <div className="contact" key={key}> 
            <p> {info.firstName}</p>
            <p> {info.lastName}</p><br></br>
            <p id="phoneNumber"> {info.phoneNumber}</p>
            <button onClick={() => {
                setIsEditing(true);
                const fandlInfo = {
                    firstName : info.firstName,
                    lastName : info.lastName,
                }
                setfirstAndLastName(fandlInfo);
            }}
            id="editButton"><FaUserEdit/></button>
            <button onClick={() => {
                deleteContact({firstName : info.firstName,lastName : info.lastName});
            }} id="trashButton"> <IoIosTrash/></button>
            
        </div>
        )
    ))}
    
    //Display all contacts
    useEffect(() =>{
    const DisplayContactInfo = async () => {
        const result = await fetch(`/api/ContactList`, {
            headers: {
                "auth-token": localStorage.getItem('token'),
                'Accept' : 'application/json',
                'Content-Type': 'application/json'
            }
        })
        const body = await result.json();
        const contactList = body.data;
        setContactInfo(contactList)
        
    
    }
    DisplayContactInfo();
    },[contactInfo]) 

    // Search contact(s) by first or last name
    const Filtering = async () => {
        const result = await fetch(`/api/${filter}`, {
            headers: {
                "auth-token": localStorage.getItem('token'),
                'Accept' : 'application/json',
                'Content-Type': 'application/json'
            }
        });
        const body = await result.json();
        const contactsInfo = body.data;
        setContactInfoFiltered(contactsInfo)
        if (body.status === "error"){
            alert(body.error);
        }
    }

    // Delete a contact

    const deleteContact = async ({firstName, lastName}) => {
        const values = firstName + "," + lastName;
        const result = await fetch(`/api/${values}`, {method: 'delete', 
        headers: {
            "auth-token": localStorage.getItem('token'),
            'Accept' : 'application/json',
            'Content-Type': 'application/json'
        }});
        const body = await result.json();
        setContactInfo(body.data)
        if (body.status === "error"){
            alert(body.error);
        }else{
            alert("Contact correctly removed.")
        }
        setfirstAndLastName({});
    }

    const editContact = async () => {
        const firstName = firstAndLastName.firstName;
        const lastName = firstAndLastName.lastName;
        const values = firstName + "," + lastName;
        const result = await fetch(`/api/${values}`, {
            method: 'put',
            body: JSON.stringify({ phoneNumber: phoneNumber}),
            headers: {
                "auth-token": localStorage.getItem('token'),
                'Accept' : 'application/json',
                'Content-Type': 'application/json'
            }
        });
        const body = await result.json();
        if (body.status === "error"){
            alert(body.error);
        }else{
            alert("phone number modified")
        }
        setIsEditing(false);
        setfirstAndLastName({});
    }


    return(
        <>
            <div className="search">
                <input type="text" placeholder="search by first or last name" value={filter} onChange={(event) => 
                    setFilter(event.target.value)}/>
                <div className="buttonsForSearch">
                    <button id="searchButton" onClick={() => {
                        Filtering();
                        setIsSearch(true)}
                        }>Search</button>
                    <button id="searchButton" onClick={() => {
                    setIsSearch(false)}
                    }>Undo search</button>
                </div>
            </div>
        <div className="contactList">
            {!isSearch && displayList(contactInfo)}
            {isSearch && displayList(contactInfoFiltered)}
            </div>
            {isEditing && 
                <div className="changePhoneNumber">
                    <input type="text" placeholder="enter new phone number" value={phoneNumber} onChange={(event) => 
                        setPhoneNumber(event.target.value)}/>
                    <button id="searchButton" onClick = {()=>{
                        editContact();
                    }}>change phone number</button>
                </div>}


        </>

    )
}


const ContactList = () => {

    return (
    <div className="wrapper">
        <div className="container2">
            <DisplayContactList/>
        </div>
    </div>
    )
}



export default ContactList;
