import React from "react";
import Registration from "../components/Registration";
import Login from "../components/Login";

const HomePage = () =>(
    <div className="wrapper">
      <div className="container">
        <h1 > Welcome </h1>
        <Registration />
        <Login/>
      </div>
  </div>
)

export default HomePage;
