import React, { Component } from 'react';
import HomePage from './pages/HomePage';
import "./App.css"
import ContactListPage from './pages/ContactListPage';

import {
  BrowserRouter as Router,
  Route,
} from 'react-router-dom';

/* Main page */ 

class App extends Component {
  render() {
    return (
      <Router>
              <Route path="/" component={HomePage} exact />
              <Route path="/login" component={ContactListPage} exact />
      </Router>

    );
  }
}

export default App;
